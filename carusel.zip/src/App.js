import Carusel from './components/Carusel';
import './App.css';

function App() {
  return (
    <Carusel />
  );
}

export default App;
